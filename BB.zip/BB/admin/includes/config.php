<?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','id22177512_rwcranchi90');
define('DB_PASS','Rwcranch@12345');
define('DB_NAME','id22177512_rwc5623');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>